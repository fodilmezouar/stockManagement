package BLL;

/**
 * Created by rifat on 8/15/15.
 */
public class UserBLL {
}
